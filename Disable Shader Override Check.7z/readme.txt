in sp and mp sdk 2013, you can't override shaders normally.
apparently they can be overriden, valve just doesn't want you to
the files provided patch this check to allow the new shader to override the old one
assembly hack provided by ficool2. i take no credit for this hack

MaterialSystem.dll (both SP and MP SDK 2013)
at 6FD80, 6 bytes long, is 0F 85 F1 00 00 00
we patch this with 90 90 90 90 90 90.

it nops this check so it never happens.
thus we can override the shaders finally